from django.shortcuts import get_object_or_404
from django.contrib.auth.models import User
from rest_framework.decorators import api_view,permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import generics
from rest_framework_simplejwt.views import TokenObtainPairView,TokenRefreshView
from .models import *
from .serializers import *
from .services import BINS,evaluate
def _client_ip(r):
 # Respect a proxy-set header first (common in real deployments behind a
 # load balancer/CDN); fall back to the direct connection address.
 forwarded=r.META.get('HTTP_X_FORWARDED_FOR')
 if forwarded:return forwarded.split(',')[0].strip()
 return r.META.get('REMOTE_ADDR')
class RegisterView(generics.CreateAPIView): serializer_class=Register; permission_classes=[AllowAny]
class LoginView(TokenObtainPairView): permission_classes=[AllowAny]
@api_view(['GET'])
def me(r):
 a=r.user.profile; return Response({'username':r.user.username,'email':r.user.email,'country':a.home_country,'locale':a.locale,'timezone':a.timezone,'account_age_days':( __import__('django').utils.timezone.now()-a.created_at).days})
@api_view(['GET'])
@permission_classes([AllowAny])
def games(r): return Response(GameS(Game.objects.all(),many=True).data)
@api_view(['GET'])
@permission_classes([AllowAny])
def game(r,id): return Response(GameS(get_object_or_404(Game,id=id)).data)
@api_view(['GET','DELETE'])
def cart(r):
 c,_=Cart.objects.get_or_create(account=r.user.profile)
 if r.method=='DELETE':c.items.all().delete();return Response(status=204)
 return Response(CartItemS(c.items.select_related('game'),many=True).data)
@api_view(['POST'])
def cart_items(r):
 c,_=Cart.objects.get_or_create(account=r.user.profile); g=get_object_or_404(Game,id=r.data['game_id']); country=r.data.get('country',r.user.profile.home_country); p=get_object_or_404(RegionalPrice,game=g,country=country); x,_=CartItem.objects.update_or_create(cart=c,game=g,country=country,defaults={'quantity':int(r.data.get('quantity',1)),'price_snapshot':p.price});return Response(CartItemS(x).data,201)
@api_view(['PATCH','DELETE'])
def cart_item(r,id):
 x=get_object_or_404(CartItem, id=id,cart__account=r.user.profile)
 if r.method=='DELETE':x.delete();return Response(status=204)
 x.quantity=int(r.data.get('quantity',x.quantity));x.save();return Response(CartItemS(x).data)
@api_view(['POST'])
def checkout(r):
 a=r.user.profile; cart_item_id=r.data.get('cart_item_id'); cart_item=get_object_or_404(CartItem,id=cart_item_id,cart__account=a) if cart_item_id else None; game_id=cart_item.game_id if cart_item else r.data.get('game_id'); g=get_object_or_404(Game,id=game_id); country=r.data.get('store_country',a.home_country); bin=str(r.data.get('card_number',''))[:6]
 if bin not in BINS:return Response({'error':'Use a supported demo card BIN'},400)
 result=evaluate(a,g,country,bin,client_ip=_client_ip(r)); p=get_object_or_404(RegionalPrice,game=g,country=country); t=Transaction.objects.create(account=a,game=g,amount=p.price,currency=p.currency,store_country=country,payment_bin=bin,payment_issuer_country=result['issuer'],ip_country=result['ipcountry'],network_type=result['network'],vpn=result['vpn'],proxy=result['proxy'],ip_risk=result['ipr'],risk_score=result['score'],decision=result['decision'],status=result['decision'],reason=result['reason']);return Response({'transaction_id':t.id,'risk_score':t.risk_score,'decision':t.decision,'reason':t.reason,'signal_source':result['signal_source']},201)
@api_view(['POST'])
def verify(r,id):
 t=get_object_or_404(Transaction,id=id,account=r.user.profile)
 if t.status!='3DS_REQUIRED':return Response({'error':'Transaction is not awaiting verification'},409)
 if r.data.get('otp')!='123456':return Response({'error':'Incorrect demo OTP'},400)
 t.status=t.decision='APPROVED';t.reason='Payment approved. Your game purchase is complete.';t.save();return Response(TxS(t).data)
@api_view(['GET'])
def transactions(r):return Response(TxS(r.user.profile.transactions.select_related('game').order_by('-created_at'),many=True).data)
@api_view(['GET'])
def transaction(r,id):return Response(TxS(get_object_or_404(Transaction,id=id,account=r.user.profile)).data)
